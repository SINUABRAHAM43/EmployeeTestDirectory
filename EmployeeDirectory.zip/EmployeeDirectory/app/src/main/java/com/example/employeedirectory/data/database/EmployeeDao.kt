package com.example.employeedirectory.data.database

import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.example.employeedirectory.data.model.Employee

interface EmployeeDao {

    @Query("SELECT * FROM Employee")
    suspend fun getAll(): List<Employee>

    @Insert
    suspend fun insertAll(employees: List<Employee>)

    @Delete
    suspend fun delete(employee: Employee)
}