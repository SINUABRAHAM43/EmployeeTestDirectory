package com.example.employeedirectory.ui.main.view

import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.employeedirectory.R
import com.example.employeedirectory.data.api.ApiHelper
import com.example.employeedirectory.data.api.ApiServiceImpl
import com.example.employeedirectory.data.model.Employee
import com.example.employeedirectory.databinding.ActivityMainBinding
import com.example.employeedirectory.ui.base.ViewModelFactory
import com.example.employeedirectory.ui.main.adapter.EmployeeListAdapter
import com.example.employeedirectory.ui.main.viewmodel.EmployeeViewModel
import com.example.employeedirectory.utils.Status
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.get


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: EmployeeListAdapter
    private lateinit var mainViewModel: EmployeeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUI()
        setupViewModel()
        setupObserver()
    }

    private fun setupUI() {
        adapter = EmployeeListAdapter(arrayListOf())
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(
                binding.recyclerView.context,
                (   binding.recyclerView.layoutManager as LinearLayoutManager).orientation
            )
        )
        binding.recyclerView.adapter = adapter
    }

    private fun setupObserver() {
        mainViewModel.getEmployees().observe(this, Observer {
            when (it.status) {
                Status.SUCCESS -> {
                    binding.progressBar.visibility = View.GONE
                    it.data?.let { users -> renderList(users) }
                    binding.recyclerView.visibility = View.VISIBLE
                }
                Status.LOADING -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.recyclerView.visibility = View.GONE
                }
                Status.ERROR -> {
                    //Handle Error
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(this, it.message, Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun renderList(users: List<Employee>) {
        adapter.addData(users)
    }

    private fun setupViewModel() {
        mainViewModel=   ViewModelProvider(this,ViewModelFactory(ApiHelper(ApiServiceImpl()))).get(EmployeeViewModel::class.java)
    }

}