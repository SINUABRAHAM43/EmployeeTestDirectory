package com.example.employeedirectory.utils


enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
